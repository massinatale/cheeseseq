package xmas.interpolationcurves;

public class DrawSmartCurve {
	
	public static void main(String args[]){
		
	}

}
